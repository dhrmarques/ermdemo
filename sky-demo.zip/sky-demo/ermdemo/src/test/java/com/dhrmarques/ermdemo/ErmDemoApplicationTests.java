package com.dhrmarques.ermdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErmDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
