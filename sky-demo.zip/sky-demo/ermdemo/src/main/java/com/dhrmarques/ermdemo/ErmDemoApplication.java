package com.dhrmarques.ermdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErmDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErmDemoApplication.class, args);
	}

}
